import React from "react";

const AboutUs = () => {
  return <div>Aboutus</div>;
};

export default AboutUs;
